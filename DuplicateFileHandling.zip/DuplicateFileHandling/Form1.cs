#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DuplicateFileManager
{
    public partial class Form1 : Form
    {
        private string? selectedFolder = null;  // Allowing null values

        private Stack<string> deletedFiles = new Stack<string>();
        private Dictionary<string, string> deletedFileBackups = new();


        public Form1()
        {
            InitializeComponent();
            SetupListView();
        }

        private void SetupListView()
        {
            listView1.View = View.Details;
            listView1.Columns.Add("File Path", 400);
            listView1.Columns.Add("Size", 100);
            listView1.Columns.Add("Type", 80);
            listView1.Columns.Add("Status", 80);
            listView1.CheckBoxes = true;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    selectedFolder = dialog.SelectedPath;
                    txtFolderPath.Text = selectedFolder ?? string.Empty; // If null, set empty string
                }
            }
        }

        private async void btnScan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedFolder))
            {
                MessageBox.Show("Please select a folder to scan.");
                return;
            }

            listView1.Items.Clear();
            await Task.Run(() => FindDuplicates());
        }

        private void FindDuplicates()
        {
            try
            {
                if (selectedFolder == null)
                {
                    MessageBox.Show("Folder path is null.");
                    return;
                }

                var files = Directory.GetFiles(selectedFolder, "*.*", SearchOption.TopDirectoryOnly);
                var fileGroups = files.GroupBy(f => GetFileHash(f));

                foreach (var group in fileGroups.Where(g => g.Count() > 1))
                {
                    var firstFile = group.First();
                    AddFileToList(firstFile, "Original");

                    foreach (var duplicate in group.Skip(1))
                    {
                        AddFileToList(duplicate, "Duplicate");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error scanning files: {ex.Message}");
            }
        }

        private void AddFileToList(string path, string status)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string, string>(AddFileToList), path, status);
                return;
            }

            var item = new ListViewItem(new[] {
                path,
                $"{new FileInfo(path).Length / 1024f:F2} KB",
                Path.GetExtension(path),
                status
            })
            {
                Checked = status == "Duplicate",
                BackColor = status == "Original" ? System.Drawing.Color.LightGreen : default
            };

            listView1.Items.Add(item);
        }

        private string GetFileHash(string filePath)
        {
            using (var md5 = MD5.Create())
            using (var stream = File.OpenRead(filePath))
            {
                return BitConverter.ToString(md5.ComputeHash(stream));
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
{
    try
    {
        if (selectedFolder == null)
        {
            MessageBox.Show("No folder selected.");
            return;
        }

        var toDelete = listView1.CheckedItems
            .Cast<ListViewItem>()
            .Where(i => i.SubItems[3].Text == "Duplicate")
            .Select(i => i.SubItems[0].Text)
            .ToList();

        foreach (var file in toDelete)
        {
            if (File.Exists(file))
            {
                // Create a backup before deleting
                string backupPath = Path.Combine(Path.GetTempPath(), Path.GetFileName(file));
                File.Copy(file, backupPath, true);
                deletedFileBackups[file] = backupPath;

                File.Delete(file);
                deletedFiles.Push(file);
            }
        }

        btnScan_Click(this, EventArgs.Empty);
        MessageBox.Show($"{toDelete.Count} files deleted");
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Delete error: {ex.Message}");
    }
}


        private void btnUndo_Click(object sender, EventArgs e)
        {
            if (deletedFiles.Count == 0)
            {
                MessageBox.Show("Nothing to undo");
                return;
            }

            try
            {
                if (selectedFolder == null)
                {
                    MessageBox.Show("No folder selected.");
                    return;
                }

                var originalPath = deletedFiles.Pop();

                if (deletedFileBackups.TryGetValue(originalPath, out string backupPath) && File.Exists(backupPath))
                {
                    string restorePath = Path.Combine(Path.GetDirectoryName(originalPath)!, Path.GetFileName(originalPath));
                    File.Copy(backupPath, restorePath, true);
                    deletedFileBackups.Remove(originalPath);

                    btnScan_Click(this, EventArgs.Empty);
                    MessageBox.Show("File restored");
                }
                else
                {
                    MessageBox.Show($"Undo failed: Backup not found for {originalPath}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Undo failed: {ex.Message}");
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
