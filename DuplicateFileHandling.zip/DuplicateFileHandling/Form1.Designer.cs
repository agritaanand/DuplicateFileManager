﻿namespace DuplicateFileManager
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox txtFolderPath;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUndo;

        /// <summary>
        /// Required method for Designer support – do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            txtFolderPath = new TextBox();
            btnBrowse = new Button();
            btnScan = new Button();
            btnDelete = new Button();
            btnUndo = new Button();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.BackColor = Color.GhostWhite;
            listView1.FullRowSelect = true;
            listView1.Location = new Point(26, 79);
            listView1.Name = "listView1";
            listView1.Size = new Size(634, 200);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // txtFolderPath
            // 
            txtFolderPath.BackColor = Color.LavenderBlush;
            txtFolderPath.Location = new Point(15, 25);
            txtFolderPath.Name = "txtFolderPath";
            txtFolderPath.Size = new Size(515, 27);
            txtFolderPath.TabIndex = 1;
            // 
            // btnBrowse
            // 
            btnBrowse.Location = new Point(555, 12);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(105, 40);
            btnBrowse.TabIndex = 2;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnScan
            // 
            btnScan.Location = new Point(42, 305);
            btnScan.Name = "btnScan";
            btnScan.Size = new Size(94, 49);
            btnScan.TabIndex = 3;
            btnScan.Text = "Scan";
            btnScan.UseVisualStyleBackColor = true;
            btnScan.Click += btnScan_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(291, 305);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 49);
            btnDelete.TabIndex = 4;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUndo
            // 
            btnUndo.Location = new Point(541, 305);
            btnUndo.Name = "btnUndo";
            btnUndo.Size = new Size(94, 49);
            btnUndo.TabIndex = 5;
            btnUndo.Text = "Undo";
            btnUndo.UseVisualStyleBackColor = true;
            btnUndo.Click += btnUndo_Click;
            // 
            // Form1
            // 
            BackColor = Color.LightCyan;
            ClientSize = new Size(697, 385);
            Controls.Add(btnUndo);
            Controls.Add(btnDelete);
            Controls.Add(btnScan);
            Controls.Add(btnBrowse);
            Controls.Add(txtFolderPath);
            Controls.Add(listView1);
            Name = "Form1";
            Text = "Duplicate File Finder";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
